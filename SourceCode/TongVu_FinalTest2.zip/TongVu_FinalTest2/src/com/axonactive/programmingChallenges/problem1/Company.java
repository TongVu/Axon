package com.axonactive.programmingChallenges.problem1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Company {
    private String name;
    List<Dlc1> listOfAllDlc1 = new ArrayList<>();
    List<Dlc2> listOfAllDlc2 = new ArrayList<>();

    public Company() {
        Dlc1 agen1 = new Dlc1("123", "one", 12, 500000);
        Dlc1 agen2 = new Dlc1("343", "two", 8, 500000);
        Dlc1 agen3 = new Dlc1("456", "three", 07, 500000);

        agen1.setComission();
        agen2.setComission();
        agen3.setComission();

        listOfAllDlc1.add(agen1);
        listOfAllDlc1.add(agen2);
        listOfAllDlc1.add(agen3);

        Dlc2 agen4 = new Dlc2("789", "four", 12, 1200000, 50000000.0 );
        Dlc2 agen5 = new Dlc2("451", "five", 20, 1200000, 12000000.0 );
        Dlc2 agen6 = new Dlc2("124", "six", 21, 1200000, 450000000.0 );

        agen4.setComission();
        agen5.setComission();
        agen6.setComission();

        agen4.setBonus();
        agen5.setBonus();
        agen6.setBonus();

        listOfAllDlc2.add(agen4);
        listOfAllDlc2.add(agen5);
        listOfAllDlc2.add(agen6);
    }

    public Company(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void inputCompanyInfo() {
        Scanner input = new Scanner(System.in);
        System.out.print("Input company name: ");
        setName(input.nextLine());
    }

    public void inputDlc1() {
        Scanner input = new Scanner(System.in);
        Dlc1 newDlc1 = new Dlc1();

        System.out.print("Input agency id: ");
        newDlc1.setId(input.nextLine());

        System.out.print("Input agency name: ");
        newDlc1.setName(input.nextLine());

        int year;
        do {
            System.out.print("Input year coorperated (postitive number): ");
            year = input.nextInt();
            newDlc1.setYearCoorperated(year);
            input.nextLine();
        } while (year <= 0);

        newDlc1.setComission();
        listOfAllDlc1.add(newDlc1);
    }

    public void inputDlc2() {
        Scanner input = new Scanner(System.in);
        Dlc2 newDlc2 = new Dlc2();

        System.out.print("Input agency id: ");
        newDlc2.setId(input.nextLine());

        System.out.print("Input agency name: ");
        newDlc2.setName(input.nextLine());

        int year;
        do {
            System.out.print("Input year coorperated (postitive number): ");
            year = input.nextInt();
            newDlc2.setYearCoorperated(year);
            input.nextLine();
        } while (year <= 0);

        double basicComission = 0;
        do {
            System.out.print("Input basic comission (positive number): ");
            basicComission = input.nextDouble();
            newDlc2.setBasicComission(basicComission);
            input.nextLine();
        } while (basicComission <= 0);

        newDlc2.setComission();
        newDlc2.setBonus();
        listOfAllDlc2.add(newDlc2);
    }

    public void inputAllDlc1() {
        Scanner input = new Scanner(System.in);
        int numberOfAgencies;

        do {
            System.out.print("Input number of agency level 1: ");
            numberOfAgencies = input.nextInt();
        } while (numberOfAgencies < 0);

        for (int i = 0; i < numberOfAgencies; i++) {
            System.out.println("AGENCY " + (i + 1));
            inputDlc1();
        }
    }

    public void inputAllDlc2() {
        Scanner input = new Scanner(System.in);
        int numberOfAgencies;

        do {
            System.out.print("Input number of agency level 2: ");
            numberOfAgencies = input.nextInt();
        } while (numberOfAgencies < 0);

        for (int i = 0; i < numberOfAgencies; i++) {
            System.out.println("AGENCY " + (i + 1));
            inputDlc2();
        }
    }

    public double showTotalComissionOfAllDlc1() {
        System.out.println("===========================================");
        double totalComission = 0;
        for (Dlc1 agency :
                listOfAllDlc1) {
            totalComission += agency.getComission();
        }
        return totalComission;
    }

    public double showTotalBonusOfAllDlc2() {
        System.out.println("===========================================");
        double totalBonus = 0;

        for (Dlc2 agency :
                listOfAllDlc2) {
            totalBonus += agency.getBonus();
        }

        return totalBonus;
    }

    public double showHighestComissionOfDlc1() {
        System.out.println("===========================================");
        double max = 0;
        for (Dlc1 agency :
                listOfAllDlc1) {
            if (agency.getComission() > max) max = agency.getBasicComission();
        }
        return max;
    }

    public double calculateTotalComissionOfAllDlc1AndDlc2() {
        System.out.println("===========================================");
        double totalComissionOfAllAgencies = 0;
        // calculate total for all dlc1
        for (Dlc1 agency :
                listOfAllDlc1) {
            totalComissionOfAllAgencies += agency.getComission();
        }

        // calculate total for all dlc2
        for (Dlc2 agency :
                listOfAllDlc2) {
            totalComissionOfAllAgencies += agency.getComission();
        }

        return totalComissionOfAllAgencies;
    }

    public void showInfoOfThreeDlHasHighestComission() {
        System.out.println("===========================================");
        List<Dlc1> dupListOfAllDlc1 = new ArrayList<>();
        dupListOfAllDlc1.addAll(listOfAllDlc1);

        List<Dlc1> threeHighestOfAgency1 = new ArrayList<>();
        double max = 0;

        //find max, add to list highest, delete that agency, repeat

        for (int i = 0; i < 3; i++) {
            for (Dlc1 agency :
                    dupListOfAllDlc1) {
                if (max < agency.getComission()) max = agency.getComission(); // found max
            }
            for (Dlc1 agency :
                    dupListOfAllDlc1) {
                if (max == agency.getComission()) {
                    threeHighestOfAgency1.add(agency); // add to 3 highest list
                    dupListOfAllDlc1.remove(agency); // remove max from dupList
                }
            }
        }

        List<Dlc2> dupListOfAllDlc2 = new ArrayList<>(listOfAllDlc2);
        List<Dlc2> threeHighestOfAgency2 = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (Dlc2 agency :
                    dupListOfAllDlc2) {
                if (max < agency.getComission()) max = agency.getComission(); // found max
            }
            for (Dlc2 agency :
                    dupListOfAllDlc2) {
                if (max == agency.getComission()) {
                    threeHighestOfAgency2.add(agency); // add to 3 highest list
                    dupListOfAllDlc2.remove(agency); // remove max from dupList
                }
            }
        }

        List<Dl> threeHighestFromAllAgencies = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (threeHighestOfAgency1.get(i).getComission() <
                        threeHighestOfAgency2.get(j).getComission()) {
                    threeHighestFromAllAgencies.add(threeHighestOfAgency2.get(j));
                    j++;
                } else if (threeHighestOfAgency1.get(i).getComission() >
                        threeHighestOfAgency2.get(j).getComission()) {
                    threeHighestFromAllAgencies.add(threeHighestOfAgency1.get(i));
                    i++;
                } else if (threeHighestOfAgency1.get(i).getComission() ==
                        threeHighestOfAgency2.get(j).getComission()) {
                    threeHighestFromAllAgencies.add(threeHighestOfAgency2.get(j));
                    threeHighestFromAllAgencies.add(threeHighestOfAgency1.get(i));
                    i++;
                    j++;
                }
            }
        }

        for (int i = 0; i < 3; i++) {
            System.out.println(threeHighestFromAllAgencies.get(i));
        }
    }

    public List<Dl> showListOfAllDlCoorperatedFromTenToTwentyYear() {
        System.out.println("===========================================");
        List<Dl> listOfAgencyFromTenToTwentyYear = null;

        for (Dlc1 agency :
                listOfAllDlc1) {
            if (agency.getYearCoorperated() >= 10 &&
                    agency.getYearCoorperated() <= 20) {
                listOfAgencyFromTenToTwentyYear.add(agency);
            }
        }
        for (Dlc2 agency :
                listOfAllDlc2) {
            if (agency.getYearCoorperated() >= 10 &&
                    agency.getYearCoorperated() <= 20) {
                listOfAgencyFromTenToTwentyYear.add(agency);
            }
        }

        return listOfAgencyFromTenToTwentyYear;
    }
}
