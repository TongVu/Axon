package com.axonactive.programmingChallenges.problem1;

import java.util.List;

public class Demo {
    public static void main(String[] args) {
        Company com = new Company();

        com.inputCompanyInfo();
        com.inputAllDlc1();
        com.inputAllDlc2();

        System.out.println("Total Comission of all Agencies 1: " + com.showTotalComissionOfAllDlc1());

        System.out.println("Total bonus of all Agencies 2: " + com.showTotalBonusOfAllDlc2());

        System.out.println("Total Comission of all agencies: " + com.calculateTotalComissionOfAllDlc1AndDlc2());


        com.showInfoOfThreeDlHasHighestComission();

        List<Dl> listFromTenToTwentyYear =
                com.showListOfAllDlCoorperatedFromTenToTwentyYear();
        for (Dl agency :
                listFromTenToTwentyYear) {
            System.out.println(agency);
        }
    }
}
