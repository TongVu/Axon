package problem9;

public class EmployeeManagementDemo {
    public static void main(String[] args) {
        SoftwareHouse mgr = new SoftwareHouse();
        mgr.menu();
    }
}
