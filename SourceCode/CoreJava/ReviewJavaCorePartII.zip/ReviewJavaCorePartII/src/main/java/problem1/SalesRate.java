package problem1;

public interface SalesRate {
    public String checkSalesRate();
}
