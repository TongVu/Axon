package problem1;

import java.text.ParseException;

public class GoodsDemo {
    public static void main(String[] args) throws ParseException {
        GoodsList productList = new GoodsList();
        productList.start();
    }
}
