package problem5;

public interface TotalIncome {
    double total() throws ExceededHoursException;
}
