package problem5;

public class InvoiceManagementDemo {
    public static void main(String[] args) throws ExceededHoursException {
        InvoiceManagement invoiceMgr = new InvoiceManagement();

//        invoiceMgr.add();
//        invoiceMgr.add();
//        invoiceMgr.numberOfInvoices();
//        invoiceMgr.showAllInvoices();
//        invoiceMgr.showAllHourlyInvoice();
//        invoiceMgr.showAllDailyInvoice();
//        System.out.println("=============================== TOTAL : " + invoiceMgr.caclTotalIncome());

        invoiceMgr.menu();

    }
}
