package problem4;

public interface TransactionExchange {

    double totalExchange();
}
